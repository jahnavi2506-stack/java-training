import java.util.*;
public class Main
{
	public static void main(String[] args) {
		ArrayList<Integer>l = new ArrayList<>();
		 l.add(1);
	     l.add(2);
	     l.add(3);
		for(int i = 0;i<l.size();i++) {
		    System.out.println(l.get(i));
		}
	}
}
