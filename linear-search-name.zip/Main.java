import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String[] names = new String[5];
	    System.out.println("Enter a name to search:");
	    for(int i=0;i<names.length;i++) {
	        System.out.print("Enter name " + (i + 1) + ": ");
	        names[i] = sc.next();
	    }
	   //Searching for name     
	   System.out.print("Enter a name to search:"); 
	   String toSearch = sc.next();
	    int i;
	    for(i = 0; i < names.length; i++) {
	        if(names[i].equals(toSearch)) {
	            System.out.print("name found");
	            break;
	        }
	    }
	    if(i == names.length) {
	        System.out.print("name not found ");
	    }

	  sc.close();
	}
}
