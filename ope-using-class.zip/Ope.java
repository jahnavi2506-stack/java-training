
public class Ope
{
    int a = 5;
    int b = 9;
    public void addition() {
      System.out.println(" Addition of " + a + " and " + b +  " is:" + (a+b));
  }
  public void subtraction() {
      System.out.println("Subtraction of " + a +  " and " + b +" is:" + (a-b));
  }
  public int multiplication(int c,int d) {
      return c * d;
  }
   public static void main(String[] args) {
      Ope obj = new Ope();
      obj.addition();
      obj.subtraction();
      int result=obj.multiplication(3,9);//if required declare int c=3,int d=9 and place c,d in ()
      System.out.println("multiplication value is:" + result);
   }
	
}
