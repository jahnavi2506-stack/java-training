import java.util.ArrayList;
public class Main
{
	public static void main(String[] args) {
	    ArrayList<Character>alphabets = new ArrayList<>();
	    for(char ch = 'A'; ch <= 'Z';ch++) {
	        alphabets.add(ch);
	    }
	    for(char ch = 'a'; ch <= 'z';ch++) {
	        alphabets.add(ch);
	    }
		System.out.println("Alphabets" + alphabets);
	}
}
