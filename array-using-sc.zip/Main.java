import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		System.out.println(" Enter names: ");
		String[] names = new String[5];
	    //take input
	    for(int i=0;i<names.length;i++) {
	        System.out.println(" Name " + (i+1) +  " is: " );
	        names[i]=sc.nextLine();
	    }
	    //display output
	    System.out.println("Names: list:");
	    for(int i=0;i<names.length;i++) {
	       System.out.println(" Name " + (i+1) + " is: " +names[i]); 
	    }
	    sc.close();
	}
}
