import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int appleCount = 0;
        int orangeCount = 0;
        int applePrice = 20;
        int orangePrice = 15;
        int choice;

        System.out.println("------ VENDING MACHINE ------");
        System.out.println("1. Buy Apple (₹20 each)");
        System.out.println("2. Buy Orange (₹15 each)");
        System.out.println("3. Exit and Print Bill");

        while (true) {
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("How many apples do you want to buy ? ");
                    appleCount = sc.nextInt(); // directly take input
                    System.out.println(appleCount + " apples added.");
                    break;

                case 2:
                    System.out.print("How many oranges do you want to buy ? ");
                    orangeCount = sc.nextInt(); // directly take input
                    System.out.println(orangeCount + " oranges added.");
                    break;

                case 3:
                    int total = (appleCount * applePrice) + (orangeCount * orangePrice);
                    System.out.println("------ BILL ------");
                    System.out.println("Apples: " + appleCount + " x ₹" + applePrice + " = ₹" + (appleCount * applePrice));
                    System.out.println("Oranges: " + orangeCount + " x ₹" + orangePrice + " = ₹" + (orangeCount * orangePrice));
                    System.out.println("Total Bill: ₹" + total);
                    System.out.println("Thank you for using the vending machine!");
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

