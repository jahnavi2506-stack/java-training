import java.util.*;
class Main
{
	public static void main(String[] args) {
	    //Creating a stack
		Stack<Integer> st1=new Stack<>();
		//adding elements
		st1.push(10);
		st1.push(20);
		st1.push(30);
		st1.push(40);
		st1.push(50);
    System.out.println(st1);
    
    Stack<Integer> st2=new Stack<>();
    while(st1.size() > 0) {
        st2.push(st1.peek());
        st1.pop();
      }
      //System.out.println(st2);
      
    Stack<Integer> st3=new Stack<>();
    while(st2.size() > 0) {
        st3.push(st2.peek());
        st2.pop();
      }
      System.out.println(st3);
	}
}


