class Node
 {   
     Node(int data) {
         this.data = data;
     }
     Node prev;
     int data;
     Node next;
 }
public class DLL {
    Node head;
    Node tail;
    int size;
     void add(int data) {
    Node temp = new Node(data);
        if(size == 0) head = tail = temp;
    else 
        {
            tail.next = temp;
            temp.prev = tail;
            tail = temp;
        }
         size++;
    }
    int size() {
        return size;
    }
    
    void display() {
        Node temp = tail;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;//only difference is use tail,prev instead of head,next
        }
        System.out.println();
    }

	public static void main(String[] args) {
	 DLL obj = new DLL();
	obj.add(4);
	obj.add(5);
	obj.add(6);
	obj.display();
	System.out.println("Size of DLL is:" + obj.size());
	
	}
}

