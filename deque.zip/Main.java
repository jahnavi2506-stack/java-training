import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Deque<Integer> dq = new ArrayDeque<>();
		dq.addFirst(12);
		dq.addFirst(10);
		dq.addFirst(1);
		//dq.peekFirst(12);
		dq.addLast(14);
		System.out.println(dq.peekFirst());
		System.out.println(dq.peekLast());
	}
}
