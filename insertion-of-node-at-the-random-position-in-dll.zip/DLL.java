 class Node
 {   
     Node(int data) {
         this.data = data;
     }
     Node prev;
     int data;
     Node next;
 }
 public class DLL {
     Node head;
     Node tail;
     int size;
     
     void add(int data) {
    Node temp = new Node(data);
        if(size == 0) head = tail = temp;
    else 
        {
            tail.next = temp;
            temp.prev = tail;
            tail = temp;
        }
         size++;
    }
    
    void insertAtHead(int val) {
        Node t = head;
        Node temp = new Node(val);
        t.prev = temp;
        temp.next = t;
        head = temp;
        size++;
    }
    
    void insertAtTail(int val) {
        add(val); // same as adding at the end
    }
    
    void insertAtIndex(int idx,int val) {
        if(idx == 0) insertAtHead(val);
          else if(idx == size) insertAtTail(val);
            else{
                Node t = head;
                Node temp = new Node(val);
                for(int i = 0;i < idx - 1;i++) {
                    t = t.next;
                }
                temp.next = t.next;
                temp.prev = t;
                t.next = temp;
                t.next.next.prev = temp;
                size++;
            }
        }
   
  
   // Display list from head to tail
  void displayForward() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
    
    // Display list from tail to head
    void displayBackward() {
        Node temp = tail;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }

public static void main(String[] args) {
    DLL obj = new DLL();
	obj.add(4);
	obj.add(5);
	obj.add(6);
	obj.add(7);
	obj.add(16);
	System.out.println("Forward:");
    obj.displayForward();  // 20 30 40

    System.out.println("Backward:");
    obj.displayBackward(); // 40 30 20

    obj.insertAtHead(10);
    System.out.println("After inserting 10 at head:");
    obj.displayForward(); 
    
    obj.insertAtIndex(3, 99);
    System.out.println("After inserting 99 at index 3:");
    obj.displayForward();
  }
} 


 
   
    
