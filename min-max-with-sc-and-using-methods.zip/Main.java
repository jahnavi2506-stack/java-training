import java.util.Scanner;

public class Main {

    // Method to input numbers
    public static int[] inputNumbers() {
        Scanner sc = new Scanner(System.in);
        int[] num = new int[5];
        System.out.println("Enter 5 numbers:");
        for (int i = 0; i < num.length; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            num[i] = sc.nextInt();
        }
        return num; // return the filled array
    }

    // Method to display the numbers
    public static void displayNumbers(int[] num) {
        System.out.println("Numbers in the list:");
        for (int i = 0; i < num.length; i++) {
            System.out.println("Number " + (i + 1) + " is: " + num[i]);
        }
    }

    // Method to find the maximum
    public static int findMax(int[] num) {
        int max = num[0];
        for (int i = 1; i < num.length; i++) {
            if (num[i] > max) {
                max = num[i];
            }
        }
        return max;
    }

    // Method to find the minimum
    public static int findMin(int[] num) {
        int min = num[0];
        for (int i = 1; i < num.length; i++) {
            if (num[i] < min) {
                min = num[i];
            }
        }
        return min;
    }

    // Main method
    public static void main(String[] args) {
        int[] numbers = inputNumbers();         // Get input
        displayNumbers(numbers);                // Show numbers
        System.out.println("The largest element is: " + findMax(numbers));
        System.out.println("The smallest element is: " + findMin(numbers));
    }
}

