class Animal {
    void eat() {
        System.out.println("Animal is eating");
    }
}

class Cow extends Animal {
    // Overloading: same method name, different parameter list
    void eat(String food) {
        System.out.println("Cow is ruminating on " + food);
    }

    public static void main(String[] args) {
        Cow c = new Cow();

        c.eat();             // calls Animal's eat()
        c.eat("grass");      // calls Cow's eat(String)
    }
}//here class main is not there so we take cow.java

     
