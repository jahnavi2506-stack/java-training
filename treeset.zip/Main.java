import java.util.*;
public class Main
{
	public static void main(String[] args) {
	   TreeSet<Integer> st = new TreeSet<>();
	    st.add(1);
	    st.add(5);
	    st.add(21);
	    st.add(11);
	    st.add(1);
	    st.add(11);
		System.out.println("size of Hashset is:" + st.size());
		System.out.println(st);
	}
}

