class Node
 {   
     Node(int data) {
         this.data = data;
     }
     Node prev;
     int data;
     Node next;
 }
 public class DLL {
     Node head;
     Node tail;
     int size;
     
     void add(int data) {
    Node temp = new Node(data);
        if(size == 0) head = tail = temp;
    else 
        {
            tail.next = temp;
            temp.prev = tail;
            tail = temp;
        }
         size++;
    }
     
     boolean palindrome() {
    Node left = head;
    Node right = tail;
    while (left != null && right != null && left != right && right.next != left) {
        if(left.data != right.data) return false;
        left = left.next;
        right = right.prev;
    }
    return true;
   }
   
   void displayForward() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
    DLL obj = new DLL();
	obj.add(1);
	obj.add(2);
	obj.add(3);
	obj.add(2);
	obj.add(1);
	
    obj.displayForward(); 
    System.out.println("Is palindrome? " + obj.palindrome());
    }
 }    