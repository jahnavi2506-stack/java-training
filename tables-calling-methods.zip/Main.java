public class Main
{
	public static void printTable(int num) {
		System.out.println("Multiplication table of " + num + " is: ");
		for(int i=1;i<=10;i++) {
		    System.out.println(+ num + "x" + i + " = " +(num*i));
		}
		System.out.println();
	}
	public static void main(String[] args) {
	   Main table =  new Main();
	   for(int n=1;n<=20;n++) {
	       table.printTable(n);
	   }
	}
}
