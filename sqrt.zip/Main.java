import java.util.Scanner;
//need not import math because java imports it directly[java.lang.Math]
class Main {
    public static int fsqrt(int num) {
        return (int) Math.pow(num,0.5);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);//system.in is used to specifically give i/p from keyboard
        System.out.println("Enter number:");
        int num = sc.nextInt();
         int result = fsqrt(num);//not sc.fsqrt because it is not part of scanner[only next(),nextInt(),nextLine()]
         System.out.println("Square root (integer part) of " + num + " is: " + result);//round value of number
         sc.close();

    }
}
