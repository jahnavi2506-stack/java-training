//import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	   // Scanner sc = new Scanner(System.in);
//printing numbers from 1-10  
	    for (int i=1;i<=10;i++) {  
	        System.out.println(i);
	    }
	    
	    
//printing even numbers from 2-20 using while
	  int j = 2; 
	  while (j <= 20) {
	      if(j%2 == 0) {
	      System.out.println("even numbers from 2-20 are: " + j);
	      }
	     j++;
	     //break is not necessary because once it runs while loop stops forever
	  }
	  
	
//print multiplication table using nested for loop
       System.out.println("Enter the table you wanted:");
       //int k = sc.nextInt();
	for(int k = 1; k <= 10; k++) {
	    System.out.println("Table of " + k + ":");
	    for(int l = 1; l <= 10; l++) {
	        System.out.println(k + " x " + l + " = " + (k * l));

	    }
	    	
	    System.out.println();
      }
      
      
//loop to reverse a number 1234-4321
      int num = 1234;
      int r = 0;
       while (num !=0) {
          int digit = num % 10;
          r = r * 10 + digit;
          num  = num / 10;
       }
          System.out.println("Reversed number is:" +r);
          
          
//sum of digits
        int n = 456;
        int sum = 0;
          while (n != 0) {
              int digits = n % 10;
              sum  = sum + digits;
              n = n / 10;
          }
	        System.out.println("Sum of the digits is:" + sum);
	        
//printing letters of name in a line	        
	        String nam = "Jahnavi";
	        for(int i = 0;i < nam.length();i++) {
	            System.out.println(nam.charAt(i));
	        }
	}     

}
