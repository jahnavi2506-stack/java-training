import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        while (T-- > 0) {
            int N = sc.nextInt();
            int Q = sc.nextInt();
            int[] A = new int[N + 2];
            for (int i = 1; i <= N; i++) {
                A[i] = sc.nextInt();
            }
            long scoreSum = 0;
            for (int i = 1; i < N; i++) {
                scoreSum += Math.min(A[i], A[i + 1]);
            }

            for (int q = 0; q < Q; q++) {
                int i = sc.nextInt();
                int X = sc.nextInt();
                if (i > 1) {
                    scoreSum -= Math.min(A[i - 1], A[i]);
                }
                if (i < N) {
                    scoreSum -= Math.min(A[i], A[i + 1]);
                }
                A[i] = X;
                if (i > 1) {
                    scoreSum += Math.min(A[i - 1], A[i]);
                }
                if (i < N) {
                    scoreSum += Math.min(A[i], A[i + 1]);
                }
                System.out.println(scoreSum);
            }
        }
        sc.close();
    }
}