public class Car
{
  String name;
  String brand;
  int noOfTyres = 4;
  //Behavior
  public void startTheCar() {
      System.out.println("Start the car");
  }
  public void stopTheCar() {
      System.out.println("Stop the car");
  }
  public  int getTyres () {
//do not use static here because non-static variable cannot be accessed with static
      return noOfTyres;
  }
  //Main Method
  public static void main(String[] args) {
      Car bmw = new Car();
      bmw.name = "bmw car";
      bmw.brand = "bmw brand";
      System.out.println("bmw info:");
      System.out.println(bmw.name);
      System.out.println(bmw.brand);
      System.out.println(bmw.noOfTyres);
      System.out.println();
      bmw.startTheCar();
      bmw.stopTheCar();
      
      
      
      Car toyota = new Car();
      toyota.name = "toyota car";
      toyota.brand = "toyota brand";
      System.out.println("toyota info:");
      System.out.println(toyota.name);
      System.out.println(toyota.brand);
      System.out.println(toyota.noOfTyres);
      toyota.startTheCar();
      toyota.stopTheCar();
      
      System.out.println();
      
      Car audi = new Car();
      audi.name = "audi car";
      audi.brand = "audi brand";
      System.out.println("audi info:");
      System.out.println(audi.name);
      System.out.println(audi.brand);
      System.out.println(audi.noOfTyres);
      audi.startTheCar();
      audi.stopTheCar();

      
  }
}
