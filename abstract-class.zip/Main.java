abstract class Animal {
     abstract void makeSound();

    void eat() {
        System.out.println("Animal eats food");
    }
}

 class Dog extends Animal {
     void makeSound() {
        System.out.println("Dog barks"); 
     }
 }

public class Main {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.makeSound();
        d.eat();
    }
}
//An abstract class in Java can have a public static void main(String[] args) method.
//Being abstract only means you cannot create an object of that class directly.
     

