import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int score = sc.nextInt();
	    if(score >= 7) {
	        System.out.println("THALA");
	    }
	    else {
	        System.out.println("BOOM");
	    }
		
	}
}
