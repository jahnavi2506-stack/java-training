class Main {
    public static void main(String[] args) {
        System.out.println("Try programiz.pro");
        System.out.print("Hello world");
        float age = 20;
        System.out.println("\nMy age is:"+ age);
   //Arithmetic operator      
         long bal1 = 50000;
         long bal2 = 68000;
         long bal = bal1 + bal2;
         System.out.println("\nTotal balance is:"+ bal);
    //Logical operator
         char ch  = 'j';
         if (ch >= 'a' || ch <= 'z') {
             System.out.println(ch);
         }
         boolean isSunny = true;
         System.out.println(isSunny);
    //Relational operator
    int a = 20;
    int b = 50;
    System.out.println(a>b);
    System.out.println(a<=b);
    System.out.println(a>=b);
    
    //braces are not necessary for single line
    int num = 21;
    if (num>20) System.out.println("greater than 20");
    else System.out.println("less than or equal to 20");
    
    int num1 = 29;
    if (num1 >= 20) System.out.println("not equal to 20");
    else System.out.println("equal to 20");
    
    //another example
    int numb = 49 ;
     if (numb%2 == 0) System.out.println("number is even" );
     else System.out.println("number is odd" );
    //power of 2 
    }
}