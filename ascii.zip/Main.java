import java.util.ArrayList;
public class Main
{
	public static void main(String[] args) {
	    ArrayList<Character>alphabets = new ArrayList();
	    for(int i = 65;i <= 90;i++) {
	        alphabets.add((char)i);
	    }
	    for(int i = 97;i <= 122;i++) {
	        alphabets.add((char)i);
	    }
		System.out.println("Alphabets" +alphabets);
	}
}
