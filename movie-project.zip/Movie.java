import java.util.Scanner;
public class Movie
{
    String heroname;//these are states
    String heroinename;
    String  Producer;
    String Director;
    int yearOfRelease;
    int cost = 0;
    
    public void ticketBooking(int gst) {
        cost = cost + gst;
        System.out.println(" total cost after adding " + gst + " is: " + cost);
        
    }
     
     public void ticketAvailability(int avail) {
         if(avail > 2) {
             System.out.println("Tickets available you can book");
         }
         else {
             System.out.println("Unable to book tickets");
         }
     }
     
     public int cost() {
         return cost;
     }
     
     public void rating(float rating) {
         if(rating >= 3.5) {
             System.out.println("Thanks for your Rating!Movie is good");
         }
         else {
             System.out.println("Thanks for your Rating!Movie is Average");
         }
         
     } 
    
    Movie(String heroname,String heroinename,String Producer,String Director,int yearOfRelease,int cost) {//use method name as constructor
        this.heroname = heroname;
        this.heroinename = heroinename;
        this.Producer = Producer;
        this.Director = Director;
        this.yearOfRelease = yearOfRelease;
        this.cost = cost;
    }
    
    public void movieDetails() {
        System.out.println("Movie details");
       System.out.println("Hero of the movie:" + heroname);
       System.out.println("Heroine of the movie:" + heroinename);
       System.out.println("producer of the movie:" + Producer);
       System.out.println("Director of the movie:" + Director);
       System.out.println("Released year :" +yearOfRelease);
       System.out.println("Ticket cost:" + cost);
    }
    
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		Movie Majili = new Movie("Naga Chaitanya","Samantha","DilRaju","Prashanth neel",2019,250);
		Movie Toliprema = new Movie("Varun Tej","Rashikanna","Raju","Prashanth",2020,150);
		Movie KGF = new Movie("Yash","Srinidhi","DilRaju","neel",2019,350);
		
		Movie[] info = {Majili,Toliprema,KGF};
		for(int i=0;i<info.length;i++) {
		    
		    info[i].movieDetails();
            info[i].ticketAvailability(10);
            info[i].ticketBooking(50);
            info[i].rating(3.5f);
            System.out.println("Final Ticket Cost: ₹" + info[i].cost());
		}
		sc.close();
	}
}
