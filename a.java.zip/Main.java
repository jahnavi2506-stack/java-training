import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int x,y;
	    Scanner sc= new Scanner(System.in);
		System.out.println("Enter x value:");
		x = sc.nextInt();
		System.out.println("Enter y value:");
		y = sc.nextInt();
		if (y >= 2*x) {
		    System.out.println("YES");
		}
		else {
		    System.out.println("NO");
		}
		sc.close();
	}
}
