import java.util.Scanner;
public class Array
{
	public static int[] inputNumbers() {
        Scanner sc = new Scanner(System.in);
        int[] num = new int[5];
        System.out.println("Enter 5 numbers:");
        for (int i = 0; i < num.length; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            num[i] = sc.nextInt();
        }
        return num; 
    }

    
    public static void displayNumbers(int[] num) {
        System.out.println("Numbers in the Array:");
        for (int i = 0; i < num.length; i++) {
            System.out.println("Number " + (i + 1) + " is: " + num[i]);
        }
    }
    public static void swapArr(int[] num) { //when void is used return is not necessary
      for(int i = 0; i < num.length / 2; i++) {
          int temp = num[i];
          num[i] = num[num.length-i-1];//[num.length-i-1] is taken to retrive the numbers from last
          num[num.length-i-1] = temp;
      }
    }  
    public static void main(String[] args) {
    int[] numbers = inputNumbers();
    displayNumbers(numbers);
    swapArr(numbers);
    System.out.println("After reversing");
    displayNumbers(numbers);
        
    }
}
//  Utility method to print array in {a, b, c} format
//     public static void printArray(int[] arr) {
//         System.out.print("{");
//         for (int i = 0; i < arr.length; i++) {
//             System.out.print(arr[i]);
//             if (i != arr.length - 1) {
//                 System.out.print(", ");
//             }
//         }
//         System.out.print("}");
//     }
