import java.util.Scanner;
public class Factorialnum
{
    public static int factorial(int n) {
        int fact = 1;
        for (int i = 1;i <= n;i++) { // for(int i=1;i>=n;i--)
            fact = fact * i;
        }
        return fact;
    }
    public static void facto(int num) {
        for(int i = 1;i <= num;i++) {
         int result = factorial(i);
		 System.out.println("factorial of " + i  + " is :" +result);
       }
    }   
       
	
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
	    int num = sc.nextInt();	//if you wanted to call use for loop after this line
	    facto(num);
  }
}
//Time complexity is o(n^2)