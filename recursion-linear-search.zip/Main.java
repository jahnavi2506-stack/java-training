import java.util.Scanner;
public class Main {
      public static int linearSearch(int[] arr, int idx, int target) {
        if (idx == -1) {
            return -1; // Base case
        }
        if (arr[idx] == target) {
            return idx; // Target 
        }
        return linearSearch(arr, idx - 1, target); // Recursive call
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numbers = new int[5];
        System.out.println("Enter 5 numbers:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Enter number " + i  + ": ");
            numbers[i] = sc.nextInt();
        }

        System.out.print("Enter a number to search: ");
        int target = sc.nextInt();

        int result = linearSearch(numbers, numbers.length - 1, target);

        if (result != -1) {
            System.out.println("Number found at index: " + result);
        } else {
            System.out.println("Number not found.");
        }

        sc.close();
    }
}
