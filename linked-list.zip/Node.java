 class Node
{
	Node(int data) {
	    this.data = data;
	}
	int data;
	Node next;
	static void display(Node head) {
	    Node temp = head;
	    while(temp != null) {
	        System.out.println(temp.data + " ");
	        temp = temp.next;
	    }
	}
	public static void main(String[] args) {

    Node a = new Node(5);
    Node b = new Node(50);
    Node c = new Node(500);
    Node d = new Node(5000);
    Node e = new Node(50000);
    a.next = b;
    b.next = c;
    c.next = d;
    d.next = e;

    // System.out.print(a.data + " ");
    // System.out.print(a.next.data + " ");//b.data also works
    // System.out.print(c.data + " ");
    // System.out.print(d.data + " ");
    // System.out.print(e.data + " ");
       display(a);//with out display only using s.o.p statements also works
   }
}