class Animal {
    void eat() {
        System.out.println("eating");
    }
}

class Cow extends Animal {
    void eat() { // same method signature as in Animal
        System.out.println("Cow is ruminating");
    }
}

class Main {
    public static void main(String[] args) {
        Cow c = new Cow();
        c.eat(); // calls overridden method in Cow
    }
}
//here there is a class named main so we take main.java
//If there’s a public class, file name = that class name.
//If no public class, you can pick any name, but usually name it after the class with main() to avoid confusion.
