import java.util.*;
class Main {
   static void display(Stack<Integer> st) { // static is necessary to use display
    if(st.size() == 0) return; //base case
    int top = st.pop();
    System.out.println(top); //3,4 self work
    display(st); //recursive case
    st.push(top);
   }
 
    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        st.push(2);
        st.push(12);
        st.push(22);
        st.push(32);
        st.push(42);
        
        display(st); // prints elements top to bottom
        System.out.println("new Stack is: " + st);
    }
}

