import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    HashMap<Integer , String> mp = new HashMap<>();
	    mp.put(1,"siri");
	    mp.put(2,"siri");
	    mp.put(3,"sara");
	    mp.put(4,"sari");
	    mp.put(5,"sari");
		System.out.println(mp);
		System.out.println();
	}
}
