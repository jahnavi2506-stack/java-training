import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    //creating a  queue
	    Queue<Integer> q = new LinkedList<>();
	    //Add elements
	    q.add(10);
	    q.add(20);
	    q.add(30);
	    
	    //Access Element 
		System.out.println(q.peek());
		System.out.println(q.size());
		System.out.println(q.isEmpty());
	}
}
