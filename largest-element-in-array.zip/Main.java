public class Main
{
	public static void main(String[] args) {
	 int [] scores= {85,90,80,42,9};
	 int max = scores[0];	 //assume largest element is at 0 index;
	 
	 for(int i=1;i < scores.length; i++) {
	 if(scores[i] > max) {
	     max = scores[i];
	   }
	}
	  System.out.println("The largest element is:" + max);
	}
}
