import java.util.Scanner;

class Main {
    public static double fsqrt(int n) {
        return Math.pow(n,0.5);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //System.out.println("Enter number:");
        int n = sc.nextInt();
        
         double result = fsqrt(n);
         
         String form = String.format("%.6f ",result); 
         System.out.println("Square root of " + n + " is: " + form);
         sc.close();

    }
}
