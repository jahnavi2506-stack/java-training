import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int A,B,C;
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter A value:");
	    A = sc.nextInt();
	    System.out.println("Enter B value:");
	    B = sc.nextInt();
	    System.out.println("Enter C value:");
	    C = sc.nextInt();
	    float Rectangle = A * B;
		System.out.println(Rectangle);
		float Square = C * C;
		System.out.println(Square);
		if ( Rectangle == Square) {
		    System.out.println("YES");
		}
		else {
		    System.out.println("NO");
		}
		sc.close();
	}
}
