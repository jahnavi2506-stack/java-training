public class Main {
    public static void printNums(int[] arr, int idx) {
        if (idx == 0) {
            System.out.println(arr[idx]);
            return;
        }
        printNums(arr, idx - 1);
        System.out.println(arr[idx]);
    }

    public static void main(String[] args) {
        int[] arr = {5, 10, 15, 20};
        int n = arr.length;
        printNums(arr, n - 1);
    }
}
