import java.util.*;
class Main
{
	public static void main(String[] args) {
	    //Creating a stack
		Stack<Integer> st=new Stack<>();
		//adding elements
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(50);
		//removing elements
// 		st.pop();
// 		st.pop();
    while(st.size() > 1) {
        st.pop();
    }
		//Accessing elements
		System.out.println(st.peek());
		System.out.println(st.size());
	}
}
