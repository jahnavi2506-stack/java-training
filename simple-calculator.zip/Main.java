import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		char ch;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter operation: ");
        ch = sc.next().charAt(0);
        int a,b,c;
        System.out.print("Enter a value: ");
        a = sc.nextInt();
        System.out.print("Enter b value: ");
        b = sc.nextInt();
        switch(ch) {
            case '+' :
                c = a + b;
                System.out.println("Addition value of operators:" +c);
                break;
            case '-' :
                c = a - b;
                System.out.println("Subtraction value of operators:" +c);
                break;
            case '*' :
                c = a * b;
                System.out.println("Multiplication value of operators:" +c);
                break;
            case '%':
                c = a % b;
                System.out.println("Modulo value of operators:" +c);
                break;
            default:
                System.out.println("Invalid operator");
        }
        sc.close();
	}
}
