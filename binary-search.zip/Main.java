//Binaray search is efficient than linear search and need to be sorted before searching
//Time complexity is O(log n)
public class Main
{
	public static void main(String[] args) {
	    int[] arr={1,2,3,4,5};
	    int target = 5;
	    int start = 0,end = 4;
	    while(start <= end) {
	        int mid = (start + end)/2;
	        if(arr[mid] == target) {
	            System.out.println(mid);
	            break;
	        }
	        else if(arr[mid] > target) end = mid - 1;
	        else start = mid + 1;
	        }
	}
}
