import java.util.Scanner;

public class Main {

    //  take input from user
    public static int[] inputNumbers() {
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[5];
        System.out.println("Enter elements in array:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print("Array " + (i + 1) + " is: ");
            arr[i] = sc.nextInt();
        }
        return arr;
    }

    //  display array elements
    public static void displayNumbers(int[] arr) {
        System.out.println("\nArray list is:");
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Array " + (i + 1) + " is: " + arr[i]);
        }
    }

    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int j = 2; j <= n / 2; j++) {
            if (n % j == 0) {
                return false;
            }
        }
        return true;
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numbers = inputNumbers();
        displayNumbers(numbers);

        // Check if a number is prime
        System.out.print("\nEnter a number to check if it's prime: ");
        int n = sc.nextInt();

        if (isPrime(n)) {
            System.out.println(n + " is a Prime Number.");
        } else {
            System.out.println(n + " is Not a Prime Number.");
        }

        sc.close();
    }
}

