public class Main {
    // Recursive method for binary search
    public static int binarySearch(int[] arr, int start, int end, int target) {
        if (start > end) {
            return -1; // Base case: not found
        }

        int mid = (start + end) / 2;

        if (arr[mid] == target) {
            return mid; // Found the target
        } else if (arr[mid] > target) {
            return binarySearch(arr, start, mid - 1, target); // Search in left half
        } else {
            return binarySearch(arr, mid + 1, end, target); // Search in right half
        }
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int target = 5;
        int start = 0, end = arr.length - 1;

        int result = binarySearch(arr, start, end, target);

        if (result != -1) {
            System.out.println("Found at index: " + result);
        } else {
            System.out.println("Not found");
        }
    }
}

