public class Bottle
{
    String name; 
    int litre;
    
	public  void fillTheWaterBottle(Boolean waterBottle,Boolean isBreak,
	int age,String name) {
	    if(waterBottle == true) {
	        System.out.println("Filling the waterBottle");
	    }
	    else {
	     System.out.println("Can't fill the waterBottle");   
	    }
		
	}
	public static void main(String[] args) {
	    Bottle bo = new Bottle();
	    bo.name = "Copper bottle";
	    bo.litre = 1;
	    bo.fillTheWaterBottle(true);
	    bo.fillTheWaterBottle(false);
	}
}
