import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		//Bitwise operator
		System.out.println(2>>1);
		System.out.println(2<<1);
		System.out.println(16<<2);
		System.out.println(16>>2);
		
       //printing a character using if-else
        char ch;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter character: ");
        ch = sc.next().charAt(0);  // takes single character from input

        if (ch == 'a') {
            System.out.println("Character is a");
        } else if (ch == 'b') {
            System.out.println("Character is b");
        } else if (ch == 'c') {
            System.out.println("Character is c");
        } else {
            System.out.println("Character is d or something else");
        }
        
        //using switch case 
        switch(ch) {
            case 'A':
                System.out.println("Character is A");
                break;
            case 'B':
                System.out.println("Character is B");
                break;    
            case 'C':
                System.out.println("Character is C");
                break;
            case 'D':
                System.out.println("Character is D");
                break;    
            default:
               System.out.println("Something else");
        } 


    //ternary operator
    System.out.println("Enter number:");
    int num = sc.nextInt();
      String result = (num%2 == 0)? "even":"odd";
      System.out.println(result);
      
    //printing patterns
    int i,j;
     System.out.println("Enter number:");
    int n = sc.nextInt();
    for (i=1;i<=n;i++) {
        for (j=1;j<=i;j++) {
         System.out.print(j +" "); //do not use println because it will be printed in next line 
        }
        System.out.println(); // moves to the next line
    
    }
	
	 sc.close();   
	}
}
