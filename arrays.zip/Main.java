public class Main
{
	public static void main(String[] args) {
	    //Declare and then intialize
	    int[] number = new int[5];//create an array with 5
	    number[0] = 10;
	    number[1] = 20;
	    number[2] = 30;
	    number[3] = 40;
	    number[4] = 50;
	    int [] scores= {85,90,80,42,50};
 		System.out.println("First number:" + number[0]);	//when you give index range out of bounds there won't be any error 
 		System.out.println("Third score:"+ scores[2]);
 		
 		String names[] = {"sruthi","Asmi","priya"};
 		System.out.println("First name:" + names[0]);
 		System.out.println("names list:");
 		for(int i=0;i<names.length;i++) {
 		    System.out.println("Name" + (i+1) +":" +names[i]);
 		}
 		System.out.println("Scores list:");
 		for(int i=0;i<scores.length;i++) {
 		    System.out.println("Scores["+ i +"]=" +scores[i]);
 	  }
	}
}