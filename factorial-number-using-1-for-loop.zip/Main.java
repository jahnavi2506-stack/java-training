import java.util.Scanner;
public class Main
{
    public static void factorial(int n) {
        int fact = 1;
        for (int i = 1;i <= n;i++) { // for(int i=1;i>=n;i--)
        fact = fact * i;
        System.out.println("factorial of " + i  + " is :" +fact);
        }
    }
 
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
	    int num = sc.nextInt();	//if you wanted to call use for loop after this line
	    factorial(num);
  }
}
//Time complexity is o(n)

