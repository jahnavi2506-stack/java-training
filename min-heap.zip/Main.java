import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    PriorityQueue<Integer> pq = new PriorityQueue<>();
	    pq.add(4);
	    pq.add(5);
	    pq.add(66);
	    pq.poll();//poll and remove are same
		System.out.println(pq.peek());
	}
}
