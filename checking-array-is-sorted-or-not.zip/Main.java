public class Main
{
    public  boolean isSorted(int[] arr){
	    for(int i=0; i<arr.length-1;i++) {
	        if(arr[i]>arr[i+1]) {
	            return false;
	        }
	    }
	    return true;
	}
	public static void main(String[] args) {
		int[] arr1 = {50,20,30,40,89};
		int[] arr2 = {5,9,3,49,8};
	    Main m = new Main();
	    System.out.println(m.isSorted(arr1));
	    System.out.println(m.isSorted(arr2));
		
	
	}
}
	

