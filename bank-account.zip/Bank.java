import java.util.Scanner;
public  class Bank //features withdraw,deposit,check balance,enquires[bulid details of customer]
{ 
    //everything passed in Enquires should be declared here
    String name;
    int age;
    String gender;
    long mobno;
    String accno;
    long balance = 0;
    
    
    public void deposit(long amt) {
        balance = balance + amt;
        System.out.println(" balance after " + amt + " deposit is: " + balance);
    }
    
    public void withDraw(long amt) {
        if(amt > balance) {
            System.out.println("insufficient balance");
        }
        else {
             balance = balance - amt;
             System.out.println(" balance after " + amt  + " withdrawl is: " + balance);
        }
    }    
        
    public double checkBalance() {
        return balance;
    }
    
    Bank(String name,int age,String gender,long mobno,String accno,long balance) {//use method name as constructor
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.mobno = mobno;
        this.accno = accno;
        this.balance = balance;
    }
    
    public  void  showDetails() { //follow camel case while declaring method name
        System.out.println(" Customer Name: " + name);
        System.out.println(" Customer Age: " + age);
        System.out.println(" Gender: " + gender);
        System.out.println(" Mobile Number: " + mobno);
        System.out.println(" Account Number: " + accno);
        System.out.println(" Current Balance: " + balance);

    }
    
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		Bank Sirisha = new Bank("Sirisha",40,"Female",9052399112L,"234560989",40000);
		Bank Siri = new Bank("Siri",40,"Female",9052399112L,"234560989",40000);
		Bank asha = new Bank("asha",40,"Female",9052399112L,"234560989",40000);
		Bank[] customers={Sirisha,Siri,asha};
		for(int i=0;i<customers.length;i++){
		    customers[i].showDetails();
		}
		
// 		Customer.Deposit(50000);
// 		Customer.Withdraw(10000);
// // 		Customer.Enquires("Sirisha",40,"Female",9052399112L,"234560989",40000);//L should be given otherwise it will be considered as int
// 		Customer.Showdetails();
// 		sc.close();
	}
}
   
