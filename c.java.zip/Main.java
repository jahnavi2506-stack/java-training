import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    float A,B,C,T,X;
	    Scanner sc = new Scanner(System.in);
	    T = sc.nextInt();
	    for(int i = 0; i < T;i++) {
	        A = sc.nextInt();
	        B = sc.nextInt();
	        C = sc.nextInt();
	        X = sc.nextInt();
	        if((A + B >= X)|| (B + C >=X) ||(C + A >=X)) {
	            System.out.println("YES");
	        }
	        else {
	            System.out.println("NO");
	        }
	   }
	}   
}
