import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int A,B,C,T;
	    Scanner sc = new Scanner(System.in);
	    T = sc.nextInt();
	    for(int i = 0;i < T;i++) {
	        A = sc.nextInt();
	        B = sc.nextInt();
	        C = sc.nextInt(); 
	        int odd = 0;
	        
	        if((A + B) % 2 == 1) 
	        odd++;
	        if((A + C ) % 2 == 1)
	         odd++;
	       if((B + C)  % 2 == 1)
	         odd++;
	        if(odd == 1) {
	            System.out.println("YES");
	        }
	        else {
	            System.out.println("NO");
	        }
	    }
	sc.close();	
	}
}
