import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    TreeMap<Integer , String> mp = new TreeMap<>();
	    mp.put(1,"siri");
	    mp.put(22,"siri");
	    mp.put(33,"sara");
	    mp.put(44,"sari");
	    mp.put(15,"sari");
		System.out.println(mp);
		System.out.println();
	}
}
