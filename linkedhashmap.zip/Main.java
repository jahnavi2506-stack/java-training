import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    LinkedHashMap<Integer , String> mp = new LinkedHashMap<>();
	    mp.put(1,"siri");
	    mp.put(22,"siri");//same name but diff num
	    mp.put(33,"sara");
	    mp.put(44,"sari");
	    mp.put(44,"sary");//same num but diff name
		System.out.println(mp);
		System.out.println();
	}
}
