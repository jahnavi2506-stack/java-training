import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int[] numbers = new int[5];
	    System.out.println("Enter a number to search:");
	    for(int i=0;i<numbers.length;i++) {
	        System.out.print("Enter number " + (i + 1) + ": ");
	        numbers[i] = sc.nextInt();
	    }
	   //Searching for name     
	   System.out.print("Enter a number to search:"); 
	   int toSearch = sc.nextInt();
	    int i;
	    for(i = 0; i < numbers.length; i++) {
	        if(numbers[i] == toSearch) {
	            System.out.print("number found");
	            break;
	        }
	    }
	    if(i == numbers.length) {
	        System.out.print("number not found ");
	    }

	  sc.close();
	}
}