public class Main {
    public static void main(String[] args) {
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };


        int middleElement = matrix[1][1]; // Second row, second column (index 1,1)
        System.out.println("Middle Element in matrix is: " + middleElement);

        // Print the matrix
        System.out.println("Matrix elements:");
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println(); // Go to next line after each row
        }
    }
}

