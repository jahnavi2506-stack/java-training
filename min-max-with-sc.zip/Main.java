import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter numbers:");
		int[] num = new int[5];
		
		for(int i=0;i<num.length;i++) {
	        System.out.println(" Number " + (i+1) +  " is: " );
	        num[i] = sc.nextInt();
	       // Sum  = Sum + num[i]; to print Sum of all the numbers
	         
		}
		System.out.println("Numbers list:");
	    for(int i=0;i<num.length;i++) {
	       System.out.println(" Number " + (i+1) + " is: " +num[i]); 
	       if(i>0) {
	       int sum = 0;
	       sum = num[i] + num[i-1];
	       System.out.println(" Sum of previous numbers  is: " +sum); 
	    }
	     System.out.println(); 
	    }
	    int max = num[0];
	     for(int i=0;i<num.length;i++) {
	         if(num[i] > max) {
	             max = num[i];
	         }
	     }
	     System.out.println("The largest element is:" + max);
	     int min = num[0];
	      for(int i=0;i<num.length;i++) {
	         if(num[i] < min) {
	             min = num[i];
	         }
	     }
	     System.out.println("The smallest element is:" + min);
	     sc.close();
	    
	}
}
