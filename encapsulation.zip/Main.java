 class Main
{
	public static void main(String[] args) {
	    Bank obj = new Bank();
		System.out.println(obj.getBalance());
		obj.setBalance(100000);
		System.out.println(obj.getBalance());
	}	
}
 
 class Bank {
     private int balance = 100;//public also works
     public int getBalance() {
         return balance;
     }
     public void setBalance(int bal) {
           balance = bal;
     }
 }