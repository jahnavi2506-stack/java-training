 class Node
{
	Node(int data) {
	    this.data = data;
	}
	int data;
	Node next;
	
	static void displayrr(Node head) {
	    if(head == null) return;
	   displayrr(head.next); //only difference for reverse order
	   System.out.println(head.data + " ");
	    
	}
	
	public static void main(String[] args) {
    Node a = new Node(5);
    Node b = new Node(50);
    Node c = new Node(500);
    Node d = new Node(5000);
    Node e = new Node(50000);
    a.next = b;
    b.next = c;
    c.next = d;
    d.next = e;
    displayrr(a);
   }
}

