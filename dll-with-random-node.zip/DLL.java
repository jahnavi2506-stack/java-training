class Node
 {   
     Node(int data) {
         this.data = data;
     }
     Node prev;
     int data;
     Node next;
 }
 public class DLL {
     Node head;
     Node tail;
     int size;
     
     void add(int data) {
    Node temp = new Node(data);
        if(size == 0) head = tail = temp;
    else 
        {
            tail.next = temp;
            temp.prev = tail;
            tail = temp;
        }
         size++;
    }
    // void insertAtHead(int val) {
    //     Node t = head;
    //     Node temp = new Node(val);
    //     t.prev = temp;
    //     temp.next = t;
    //     head = temp;
    //     size++;
    // }
    
 void displayRandom(Node random) {
     Node temp = random;
     while (temp.prev != null) {
            temp = temp.prev;
        }
    while(temp != null) {
        System.out.print(temp.data+" ");
        temp = temp.next;
    }
    System.out.println();
  }

public static void main(String[] args) {
    DLL obj = new DLL();
	obj.add(4);
	obj.add(5);
	obj.add(6);
	obj.add(7);
	obj.add(16);
	Node random = obj.head.next.next;
    obj. displayRandom(random);
  }
} 

