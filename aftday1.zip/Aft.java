
import java.util.Scanner;
public class Aft
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		
		//for loop
		for(int i=1;i<10;i++)
		{
		  System.out.println(i);  
		}
		
		//while loop
		int j=0;
		while(j<10) {
		j++;
		System.out.println(j);
		}
		int k = 1;
		  System.out.println(++k);
		 int x = 5; 
		  System.out.println(x++);
		 int l = 8; 
		  System.out.println(--l);
		 int m = 6; 
		  System.out.println(m--);
		  
		 int a = 10;
            System.out.println(++a);  // prints 11
            System.out.println(a);    // prints 11

        int b = 10;
            System.out.println(b++);  // prints 10
            System.out.println(b);    // prints 11

	}
}
