import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    char ch;
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter Character:");
		 ch =sc.next().charAt(0);
		switch(ch) {
		    case 'A' :
		        System.out.println("Excellent");
		        break;
		    case 'B' :
		        System.out.println("Good");
		        break;
		    case 'C' :
		        System.out.println("Average");
		//if default condition is not given no error will be displayed but o/p will be empty      
		        
		    
		}
	}
}
