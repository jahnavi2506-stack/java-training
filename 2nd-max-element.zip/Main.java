import java.util.Arrays;//* can also be used

public class Main {
    public static void main(String[] args) {
        int[] arr = {12, 45, 67, 12, 23, 89, 34}; 

        Arrays.sort(arr); // sort the array in ascending order

        System.out.println("Sorted order is: " + Arrays.toString(arr));
        System.out.println("Largest element is: " + arr[arr.length - 1]);
        System.out.println("Second largest element is: " + arr[arr.length - 2]);
    }
}
