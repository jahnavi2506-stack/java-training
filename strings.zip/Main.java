public class Main
{
	public static void main(String[] args) {
	    String name = "Jahnavi";
	    String greeting = new String("Hello");
	    
		System.out.println("Name:" + name);
		System.out.println("Greetings:" + greeting);
		System.out.println("Length of Name:" + name.length());
		System.out.println("Second Element of name:" + name.charAt(1));
		String fullGreetings = name + "," + greeting + "!";
		System.out.println(fullGreetings);
		System.out.println(name + greeting);//prints without space
		String str1 = "hello";
		String str2 = "hello";
		String str3 = new String("hello");
		System.out.println(str1 == str3);
		System.out.println(str1 + str3);
		String messy = "   rishitha  ";
		String trimmedMessy = messy.trim();
		System.out.println("Messy girl:" +trimmedMessy);
		
	}
}
